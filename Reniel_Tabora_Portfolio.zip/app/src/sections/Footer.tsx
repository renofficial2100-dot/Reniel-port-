import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Github, Linkedin, Twitter, Dribbble, Mail, MapPin, Calendar, ArrowUpRight, Send } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const socialLinks = [
  { icon: Github, label: 'GitHub', href: '#' },
  { icon: Linkedin, label: 'LinkedIn', href: '#' },
  { icon: Twitter, label: 'Twitter', href: '#' },
  { icon: Dribbble, label: 'Dribbble', href: '#' }
];

const quickLinks = [
  { label: 'Home', href: '#hero' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Projects', href: '#projects' },
  { label: 'Contact', href: '#contact' }
];

export default function Footer() {
  const sectionRef = useRef<HTMLElement>(null);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // CTA headline animation
      gsap.fromTo('.footer-cta',
        { scale: 0.9, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Contact items stagger
      gsap.fromTo('.contact-item',
        { x: -30, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.contact-items',
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Social icons stagger
      gsap.fromTo('.social-icon',
        { scale: 0, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.4,
          stagger: 0.08,
          ease: 'back.out(1.7)',
          scrollTrigger: {
            trigger: '.social-icons',
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Quick links
      gsap.fromTo('.quick-link',
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.4,
          stagger: 0.05,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.quick-links',
            start: 'top 90%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
      
      setTimeout(() => setIsSubmitted(false), 3000);
    }, 1500);
  };

  return (
    <footer 
      ref={sectionRef}
      id="contact"
      className="relative w-full bg-black text-white"
    >
      {/* Main CTA Section */}
      <div className="relative py-24 md:py-32 overflow-hidden">
        {/* Background particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white/20 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `float ${Math.random() * 5 + 5}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 5}s`
              }}
            />
          ))}
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-8 text-center">
          <div className="footer-cta">
            <h2 className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-bold text-gradient-shimmer mb-6">
              LET'S WORK
            </h2>
            <h2 className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-bold mb-8">
              TOGETHER
            </h2>
            <p className="text-xl text-white/60 max-w-xl mx-auto mb-12">
              Have a project in mind? Let's create something amazing.
            </p>
            <a 
              href="mailto:hello@alexmorgan.dev"
              className="inline-flex items-center gap-3 px-10 py-5 bg-white text-black font-display text-lg uppercase tracking-wider hover:bg-transparent hover:text-white border-2 border-white transition-all duration-300 glow-pulse"
            >
              Get In Touch
              <ArrowUpRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>

      {/* Contact Form & Info Section */}
      <div className="border-t border-white/10 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div>
              <h3 className="font-display text-2xl font-bold mb-8">SEND A MESSAGE</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <input
                    type="text"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-transparent border-b border-white/20 py-4 text-white placeholder:text-white/40 focus:border-white focus:outline-none transition-colors"
                    required
                  />
                </div>
                
                <div>
                  <input
                    type="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-transparent border-b border-white/20 py-4 text-white placeholder:text-white/40 focus:border-white focus:outline-none transition-colors"
                    required
                  />
                </div>
                
                <div>
                  <textarea
                    placeholder="Your Message"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={4}
                    className="w-full bg-transparent border-b border-white/20 py-4 text-white placeholder:text-white/40 focus:border-white focus:outline-none transition-colors resize-none"
                    required
                  />
                </div>
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center gap-3 px-8 py-4 border border-white/30 hover:bg-white hover:text-black transition-all duration-300 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    'Sending...'
                  ) : isSubmitted ? (
                    'Message Sent!'
                  ) : (
                    <>
                      Send Message
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="font-display text-2xl font-bold mb-8">CONTACT INFO</h3>
              
              <div className="contact-items space-y-6">
                <div className="contact-item flex items-center gap-4">
                  <div className="w-12 h-12 flex items-center justify-center border border-white/20">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-white/50 text-sm">Email</p>
                    <a href="mailto:hello@alexmorgan.dev" className="hover:text-white/70 transition-colors">
                      hello@alexmorgan.dev
                    </a>
                  </div>
                </div>
                
                <div className="contact-item flex items-center gap-4">
                  <div className="w-12 h-12 flex items-center justify-center border border-white/20">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-white/50 text-sm">Location</p>
                    <p>San Francisco, CA</p>
                  </div>
                </div>
                
                <div className="contact-item flex items-center gap-4">
                  <div className="w-12 h-12 flex items-center justify-center border border-white/20">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-white/50 text-sm">Availability</p>
                    <p>Open for projects</p>
                  </div>
                </div>
              </div>

              {/* Social Links */}
              <div className="mt-12">
                <p className="text-white/50 text-sm mb-4">Follow Me</p>
                <div className="social-icons flex gap-4">
                  {socialLinks.map((social) => {
                    const Icon = social.icon;
                    return (
                      <a
                        key={social.label}
                        href={social.href}
                        className="social-icon w-12 h-12 flex items-center justify-center border border-white/20 hover:bg-white hover:text-black transition-all duration-300"
                        aria-label={social.label}
                      >
                        <Icon className="w-5 h-5" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Quick Links */}
            <nav className="quick-links flex flex-wrap justify-center gap-6">
              {quickLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="quick-link text-sm text-white/50 hover:text-white transition-colors relative group"
                >
                  {link.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-white group-hover:w-full transition-all duration-300" />
                </a>
              ))}
            </nav>

            {/* Copyright */}
            <p className="text-white/40 text-sm text-center">
              © 2024 Alex Morgan. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

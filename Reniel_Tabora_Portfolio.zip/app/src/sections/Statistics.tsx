import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { value: 150, suffix: '+', label: 'Projects Completed', subtext: 'Across 15 countries' },
  { value: 8, suffix: '', label: 'Years Experience', subtext: 'Of continuous growth' },
  { value: 50, suffix: '+', label: 'Happy Clients', subtext: '90% return rate' },
  { value: 12, suffix: '', label: 'Awards Won', subtext: 'Industry recognition' }
];

function Counter({ value, suffix, isVisible }: { value: number; suffix: string; isVisible: boolean }) {
  const [count, setCount] = useState(0);
  const countRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (!isVisible) return;

    const duration = 2000;
    const startTime = Date.now();
    const endValue = value;

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Ease out function
      const easeOut = 1 - Math.pow(1 - progress, 3);
      const currentValue = Math.floor(easeOut * endValue);
      
      setCount(currentValue);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [value, isVisible]);

  return (
    <span ref={countRef} className="tabular-nums">
      {count}{suffix}
    </span>
  );
}

export default function Statistics() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Trigger counter animation when section is visible
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top 60%',
        onEnter: () => setIsVisible(true),
        once: true
      });

      // Stats cards animation
      const statCards = statsRef.current?.querySelectorAll('.stat-card');
      if (statCards) {
        gsap.fromTo(statCards,
          { rotateX: -90, y: 100, opacity: 0 },
          {
            rotateX: 0,
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.15,
            ease: 'back.out(1.7)',
            scrollTrigger: {
              trigger: statsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Connecting lines animation
      const lines = sectionRef.current?.querySelectorAll('.connecting-line');
      if (lines) {
        lines.forEach((line) => {
          const path = line as SVGPathElement;
          const length = path.getTotalLength?.() || 1000;
          gsap.set(path, { strokeDasharray: length, strokeDashoffset: length });
          
          gsap.to(path, {
            strokeDashoffset: 0,
            duration: 1.2,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 60%',
              toggleActions: 'play none none reverse'
            }
          });
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="statistics"
      className="relative w-full py-24 md:py-32 bg-black text-white overflow-hidden"
    >
      {/* Radial gradient background */}
      <div 
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(30,30,30,1) 0%, rgba(0,0,0,1) 70%)'
        }}
      />

      {/* Connecting lines SVG */}
      <svg 
        className="absolute inset-0 w-full h-full pointer-events-none opacity-20"
        preserveAspectRatio="none"
      >
        <path 
          className="connecting-line"
          d="M 0 50% Q 25% 30%, 50% 50% T 100% 50%"
          fill="none"
          stroke="white"
          strokeWidth="1"
        />
      </svg>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section header */}
        <div className="text-center mb-16 md:mb-24">
          <span className="text-white/50 text-sm uppercase tracking-[0.3em] mb-4 block">Achievements</span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold">
            NUMBERS THAT SPEAK
          </h2>
        </div>

        {/* Stats grid */}
        <div 
          ref={statsRef}
          className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12"
        >
          {stats.map((stat, index) => (
            <div 
              key={stat.label}
              className="stat-card relative text-center preserve-3d"
              style={{ 
                transformStyle: 'preserve-3d',
                marginTop: index % 2 === 1 ? '2rem' : '0'
              }}
            >
              {/* Number */}
              <div 
                className="font-display text-6xl sm:text-7xl md:text-8xl lg:text-[120px] font-bold leading-none mb-4 glow-pulse"
                style={{
                  textShadow: '0 0 40px rgba(255,255,255,0.2)'
                }}
              >
                <Counter value={stat.value} suffix={stat.suffix} isVisible={isVisible} />
              </div>

              {/* Label */}
              <h3 className="font-display text-lg md:text-xl font-semibold uppercase tracking-wider mb-2">
                {stat.label}
              </h3>

              {/* Subtext */}
              <p className="text-white/50 text-sm">
                {stat.subtext}
              </p>

              {/* Decorative element */}
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-12 h-[2px] bg-white/20" />
            </div>
          ))}
        </div>

        {/* Bottom quote */}
        <div className="mt-24 text-center">
          <blockquote className="text-xl md:text-2xl text-white/60 italic max-w-3xl mx-auto">
            "Quality is not an act, it is a habit. Every project is an opportunity to exceed expectations."
          </blockquote>
        </div>
      </div>

      {/* Particle burst decoration */}
      <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/30 rounded-full animate-ping" />
      <div className="absolute bottom-1/3 right-1/4 w-1 h-1 bg-white/20 rounded-full animate-ping" style={{ animationDelay: '1s' }} />
      <div className="absolute top-1/2 right-1/3 w-1.5 h-1.5 bg-white/25 rounded-full animate-ping" style={{ animationDelay: '0.5s' }} />
    </section>
  );
}

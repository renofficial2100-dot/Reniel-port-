import { useEffect, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import * as THREE from 'three';
import gsap from 'gsap';

// Floating geometric shapes
function FloatingShapes() {
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.05;
      groupRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.1) * 0.1;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Cube */}
      <mesh position={[-4, 2, -5]}>
        <boxGeometry args={[0.8, 0.8, 0.8]} />
        <meshStandardMaterial color="#ffffff" wireframe opacity={0.3} transparent />
      </mesh>
      
      {/* Octahedron */}
      <mesh position={[4, -1, -6]}>
        <octahedronGeometry args={[0.6]} />
        <meshStandardMaterial color="#ffffff" wireframe opacity={0.25} transparent />
      </mesh>
      
      {/* Tetrahedron */}
      <mesh position={[-3, -2, -4]}>
        <tetrahedronGeometry args={[0.5]} />
        <meshStandardMaterial color="#ffffff" wireframe opacity={0.2} transparent />
      </mesh>
      
      {/* Icosahedron */}
      <mesh position={[3, 3, -7]}>
        <icosahedronGeometry args={[0.7]} />
        <meshStandardMaterial color="#ffffff" wireframe opacity={0.15} transparent />
      </mesh>
      
      {/* Torus */}
      <mesh position={[0, 4, -8]} rotation={[Math.PI / 4, 0, 0]}>
        <torusGeometry args={[0.8, 0.2, 8, 20]} />
        <meshStandardMaterial color="#ffffff" wireframe opacity={0.2} transparent />
      </mesh>
    </group>
  );
}

// Animated particles
function ParticleField() {
  const pointsRef = useRef<THREE.Points>(null);
  const particleCount = 200;
  
  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 30;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 30;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 20;
  }
  
  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });
  
  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial size={0.05} color="#ffffff" opacity={0.6} transparent />
    </points>
  );
}

// Main 3D Scene
function Scene3D() {
  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={0.5} />
      <Stars radius={100} depth={50} count={1000} factor={4} saturation={0} fade speed={1} />
      <FloatingShapes />
      <ParticleField />
      <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
    </>
  );
}

export default function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
    
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo('.hero-title-line',
        { rotateY: -90, opacity: 0 },
        { 
          rotateY: 0, 
          opacity: 1, 
          duration: 0.8, 
          stagger: 0.15,
          ease: 'power4.out',
          delay: 0.3
        }
      );
      
      // Subtitle animation
      gsap.fromTo(subtitleRef.current,
        { filter: 'blur(20px)', opacity: 0 },
        { filter: 'blur(0px)', opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.9 }
      );
      
      // CTA animation
      gsap.fromTo(ctaRef.current,
        { scale: 0, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.5, ease: 'elastic.out(1, 0.5)', delay: 1.1 }
      );
    }, heroRef);
    
    return () => ctx.revert();
  }, []);

  const scrollToProjects = () => {
    const projectsSection = document.getElementById('projects');
    if (projectsSection) {
      projectsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      ref={heroRef}
      id="hero"
      className="relative w-full h-screen overflow-hidden bg-black"
    >
      {/* 3D Background */}
      <div className="absolute inset-0 z-0">
        <Canvas camera={{ position: [0, 0, 10], fov: 60 }}>
          <Scene3D />
        </Canvas>
      </div>
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black z-[1]" />
      
      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full px-4 sm:px-8">
        <div ref={titleRef} className="perspective-1200 text-center">
          <div className="overflow-hidden">
            <h1 
              className={`hero-title-line font-display text-6xl sm:text-7xl md:text-8xl lg:text-9xl xl:text-[120px] font-extrabold text-white leading-[0.9] preserve-3d ${isLoaded ? '' : 'opacity-0'}`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              CREATIVE
            </h1>
          </div>
          <div className="overflow-hidden">
            <h1 
              className={`hero-title-line font-display text-6xl sm:text-7xl md:text-8xl lg:text-9xl xl:text-[120px] font-extrabold text-white leading-[0.9] preserve-3d ${isLoaded ? '' : 'opacity-0'}`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              DEVELOPER
            </h1>
          </div>
          <div className="overflow-hidden">
            <h1 
              className={`hero-title-line font-display text-6xl sm:text-7xl md:text-8xl lg:text-9xl xl:text-[120px] font-extrabold text-white leading-[0.9] preserve-3d ${isLoaded ? '' : 'opacity-0'}`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              <span className="text-white/80">&</span> DESIGNER
            </h1>
          </div>
        </div>
        
        <p 
          ref={subtitleRef}
          className="mt-8 text-lg sm:text-xl md:text-2xl text-white/70 text-center max-w-2xl font-body opacity-0"
        >
          Crafting digital experiences that captivate, convert, and leave lasting impressions
        </p>
        
        <button
          ref={ctaRef}
          onClick={scrollToProjects}
          className="magnetic-button mt-12 px-8 py-4 bg-white text-black font-display font-semibold text-lg uppercase tracking-wider hover:bg-transparent hover:text-white border-2 border-white transition-all duration-300 opacity-0"
        >
          Explore My Work
        </button>
      </div>
      
      {/* Floating decorative elements */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-bounce" />
        </div>
      </div>
    </section>
  );
}

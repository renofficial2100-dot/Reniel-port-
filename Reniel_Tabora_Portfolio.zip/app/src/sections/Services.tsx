import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Code, Palette, Fingerprint, Sparkles, Lightbulb } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    icon: Code,
    title: 'Web Development',
    description: 'Custom websites built with modern technologies, optimized for performance and scalability.',
    tags: ['React', 'Node.js', 'Next.js'],
    color: '#3b82f6'
  },
  {
    icon: Palette,
    title: 'UI/UX Design',
    description: 'User-centered design that combines aesthetics with functionality for optimal experiences.',
    tags: ['Figma', 'Prototyping', 'Research'],
    color: '#ec4899'
  },
  {
    icon: Fingerprint,
    title: 'Brand Identity',
    description: 'Complete visual identity systems that communicate your brand\'s unique story.',
    tags: ['Logo', 'Guidelines', 'Strategy'],
    color: '#f59e0b'
  },
  {
    icon: Sparkles,
    title: 'Motion Design',
    description: 'Captivating animations and interactions that bring your digital products to life.',
    tags: ['After Effects', 'Lottie', 'CSS'],
    color: '#8b5cf6'
  },
  {
    icon: Lightbulb,
    title: 'Consulting',
    description: 'Strategic guidance to help you make informed decisions about your digital presence.',
    tags: ['Audit', 'Planning', 'Growth'],
    color: '#10b981'
  }
];

export default function Services() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(titleRef.current,
        { clipPath: 'polygon(0 50%, 100% 50%, 100% 50%, 0 50%)' },
        {
          clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
          duration: 0.8,
          ease: 'power3.inOut',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Cards stagger animation
      const cards = cardsRef.current?.querySelectorAll('.service-card');
      if (cards) {
        gsap.fromTo(cards,
          { y: 60, opacity: 0, rotateY: -30 },
          {
            y: 0,
            opacity: 1,
            rotateY: 0,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="services"
      className="relative w-full min-h-screen bg-black text-white py-24 md:py-32 overflow-hidden"
    >
      {/* Starfield background */}
      <div className="absolute inset-0">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full star-twinkle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: Math.random() * 0.5 + 0.2,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${Math.random() * 3 + 2}s`
            }}
          />
        ))}
      </div>

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section header */}
        <div className="text-center mb-16 md:mb-24">
          <div ref={titleRef} className="overflow-hidden">
            <h2 className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold">
              SERVICES I OFFER
            </h2>
          </div>
          <p className="mt-6 text-lg text-white/60 max-w-xl mx-auto">
            Comprehensive solutions tailored to your needs
          </p>
        </div>

        {/* Service cards */}
        <div 
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6"
        >
          {services.map((service, index) => {
            const Icon = service.icon;
            const isHovered = hoveredIndex === index;
            
            return (
              <div
                key={service.title}
                className="service-card group relative glass-card p-6 md:p-8 cursor-pointer preserve-3d"
                style={{
                  transform: isHovered 
                    ? 'translateZ(30px) rotateY(5deg) scale(1.02)' 
                    : 'translateZ(0) rotateY(0) scale(1)',
                  transition: 'transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
                }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                {/* Glow effect on hover */}
                <div 
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{
                    background: `radial-gradient(circle at center, ${service.color}20 0%, transparent 70%)`
                  }}
                />

                {/* Icon */}
                <div 
                  className="relative w-14 h-14 mb-6 flex items-center justify-center border border-white/20 transition-all duration-300 group-hover:border-white/40 group-hover:scale-110"
                  style={{ 
                    boxShadow: isHovered ? `0 0 20px ${service.color}40` : 'none'
                  }}
                >
                  <Icon 
                    className="w-7 h-7 transition-colors duration-300" 
                    style={{ color: isHovered ? service.color : 'white' }}
                  />
                </div>

                {/* Content */}
                <h3 className="font-display text-xl md:text-2xl font-bold mb-3">
                  {service.title}
                </h3>
                
                <p className="text-sm text-white/60 mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {service.tags.map((tag) => (
                    <span 
                      key={tag}
                      className="px-3 py-1 text-xs uppercase tracking-wider border border-white/20 text-white/70"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Corner accent */}
                <div 
                  className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-white/0 group-hover:border-white/30 transition-all duration-300"
                  style={{ borderColor: isHovered ? `${service.color}60` : 'transparent' }}
                />
                <div 
                  className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-white/0 group-hover:border-white/30 transition-all duration-300"
                  style={{ borderColor: isHovered ? `${service.color}60` : 'transparent' }}
                />
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="mt-20 text-center">
          <p className="text-white/50 mb-6">Need something custom?</p>
          <a 
            href="#contact"
            className="inline-flex items-center gap-2 px-8 py-4 border border-white/30 text-white font-display uppercase tracking-wider hover:bg-white hover:text-black transition-all duration-300"
          >
            Let's Discuss Your Project
          </a>
        </div>
      </div>
    </section>
  );
}

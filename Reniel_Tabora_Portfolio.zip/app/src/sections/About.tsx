import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const textBlocksRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const watermarkRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Watermark animation
      gsap.fromTo(watermarkRef.current,
        { scale: 0.8, opacity: 0 },
        {
          scale: 1,
          opacity: 0.03,
          duration: 1.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Headline word-by-word reveal
      const words = headlineRef.current?.querySelectorAll('.word');
      if (words) {
        gsap.fromTo(words,
          { clipPath: 'inset(0 100% 0 0)' },
          {
            clipPath: 'inset(0 0% 0 0)',
            duration: 0.5,
            stagger: 0.1,
            ease: 'power3.inOut',
            scrollTrigger: {
              trigger: headlineRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Text blocks animation
      const blocks = textBlocksRef.current?.querySelectorAll('.text-block');
      if (blocks) {
        gsap.fromTo(blocks,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: textBlocksRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Image reveal animation
      gsap.fromTo(imageRef.current,
        { clipPath: 'circle(0%)', rotateY: -15 },
        {
          clipPath: 'circle(75%)',
          rotateY: 0,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: imageRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Parallax effect on scroll
      gsap.to(imageRef.current, {
        y: -50,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="about"
      className="relative w-full min-h-screen bg-white text-black py-24 md:py-32 overflow-hidden"
    >
      {/* Background watermark */}
      <div 
        ref={watermarkRef}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 font-display text-[200px] md:text-[300px] font-bold text-black opacity-0 pointer-events-none select-none whitespace-nowrap"
      >
        ABOUT
      </div>

      {/* Grid pattern background */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(to right, #000 1px, transparent 1px),
            linear-gradient(to bottom, #000 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section label */}
        <div className="flex items-center gap-4 mb-12">
          <div className="w-12 h-[2px] bg-black" />
          <span className="font-display text-sm tracking-[0.3em] uppercase">About Me</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <div className="order-2 lg:order-1">
            <h2 
              ref={headlineRef}
              className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-[0.95] mb-10"
            >
              <span className="word inline-block">I</span>{' '}
              <span className="word inline-block">TRANSFORM</span>{' '}
              <span className="word inline-block">IDEAS</span>{' '}
              <span className="word inline-block">INTO</span>{' '}
              <span className="word inline-block">DIGITAL</span>{' '}
              <span className="word inline-block">REALITY</span>
            </h2>

            <div ref={textBlocksRef} className="space-y-6">
              <p className="text-block text-lg text-black/70 leading-relaxed">
                With over <span className="font-semibold text-black">8 years of experience</span> in web development 
                and design, I've helped businesses across the globe establish their digital presence. My approach 
                combines technical expertise with creative vision.
              </p>
              
              <p className="text-block text-lg text-black/70 leading-relaxed">
                From <span className="font-semibold text-black">startups to enterprise clients</span>, I bring the 
                same level of dedication and attention to detail to every collaboration. Every project is an 
                opportunity to create something exceptional.
              </p>
              
              <p className="text-block text-lg text-black/70 leading-relaxed">
                I specialize in <span className="font-semibold text-black">React, TypeScript, Three.js</span>, and 
                modern web technologies. My designs are not just visually stunning—they're built to perform and scale.
              </p>
            </div>

            {/* Signature */}
            <div className="mt-12 flex items-center gap-6">
              <div className="w-20 h-[2px] bg-black" />
              <div>
                <p className="font-display text-2xl font-bold">Alex Morgan</p>
                <p className="text-sm text-black/60 uppercase tracking-wider">Creative Developer</p>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="order-1 lg:order-2 flex justify-center lg:justify-end">
            <div 
              ref={imageRef}
              className="relative w-full max-w-md aspect-[3/4] overflow-hidden"
              style={{ clipPath: 'circle(0%)' }}
            >
              {/* Animated border */}
              <div className="absolute inset-0 z-10 pointer-events-none">
                <div className="absolute inset-0 border-2 border-black/10" />
                <div 
                  className="absolute inset-0 border-2 border-transparent"
                  style={{
                    background: 'linear-gradient(90deg, #000 50%, transparent 50%)',
                    backgroundSize: '200% 100%',
                    animation: 'shimmer 3s linear infinite',
                    WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                    WebkitMaskComposite: 'xor',
                    maskComposite: 'exclude',
                    padding: '2px'
                  }}
                />
              </div>
              
              {/* Profile image */}
              <div className="w-full h-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-gray-400 to-gray-600 flex items-center justify-center">
                    <span className="font-display text-5xl text-white font-bold">AM</span>
                  </div>
                  <p className="font-display text-xl text-gray-600">Alex Morgan</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'CEO, TechStart Inc.',
    quote: 'Alex transformed our vision into reality. The attention to detail and creative solutions exceeded our expectations. Our conversion rate increased by 150%.',
    rating: 5,
    initials: 'SJ',
    color: '#3b82f6'
  },
  {
    name: 'Michael Chen',
    role: 'Marketing Director, GlobalBrand',
    quote: 'Working with Alex was a game-changer for our brand. The new identity perfectly captures who we are. Highly recommend!',
    rating: 5,
    initials: 'MC',
    color: '#ec4899'
  },
  {
    name: 'Emily Rodriguez',
    role: 'Product Manager, InnovateCo',
    quote: 'The level of professionalism and creativity Alex brings is unmatched. Our app has never looked better.',
    rating: 5,
    initials: 'ER',
    color: '#10b981'
  }
];

export default function Testimonials() {
  const sectionRef = useRef<HTMLElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const cardsRef = useRef<HTMLDivElement>(null);

  const goToSlide = (index: number) => {
    if (isAnimating || index === activeIndex) return;
    setIsAnimating(true);
    setActiveIndex(index);
    setTimeout(() => setIsAnimating(false), 600);
  };

  const nextSlide = () => {
    goToSlide((activeIndex + 1) % testimonials.length);
  };

  const prevSlide = () => {
    goToSlide((activeIndex - 1 + testimonials.length) % testimonials.length);
  };

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo('.testimonials-title',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Cards entrance
      gsap.fromTo('.testimonial-card',
        { opacity: 0, rotateY: 30 },
        {
          opacity: 1,
          rotateY: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Auto-advance slides
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isAnimating) {
        nextSlide();
      }
    }, 6000);

    return () => clearInterval(interval);
  }, [activeIndex, isAnimating]);

  return (
    <section 
      ref={sectionRef}
      id="testimonials"
      className="relative w-full py-24 md:py-32 bg-white text-black overflow-hidden"
    >
      {/* Decorative quote marks */}
      <div className="absolute top-20 left-10 text-[200px] font-serif text-black/5 leading-none pointer-events-none select-none">
        "
      </div>
      <div className="absolute bottom-20 right-10 text-[200px] font-serif text-black/5 leading-none pointer-events-none select-none rotate-180">
        "
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-8">
        {/* Section header */}
        <div className="testimonials-title text-center mb-16">
          <span className="text-black/50 text-sm uppercase tracking-[0.3em] mb-4 block">Testimonials</span>
          <h2 className="font-display text-5xl sm:text-6xl md:text-7xl font-bold">
            CLIENT STORIES
          </h2>
          <p className="mt-4 text-black/60 max-w-xl mx-auto">
            What people say about working with me
          </p>
        </div>

        {/* Testimonials carousel */}
        <div 
          ref={cardsRef}
          className="relative perspective-1200"
        >
          {/* Cards container */}
          <div className="relative h-[400px] md:h-[350px]">
            {testimonials.map((testimonial, index) => {
              const isActive = index === activeIndex;
              const isPrev = index === (activeIndex - 1 + testimonials.length) % testimonials.length;
              const isNext = index === (activeIndex + 1) % testimonials.length;
              
              let transform = 'translateX(100%) translateZ(-100px) rotateY(30deg) scale(0.8)';
              let opacity = 0;
              let zIndex = 0;
              
              if (isActive) {
                transform = 'translateX(0) translateZ(100px) rotateY(0) scale(1)';
                opacity = 1;
                zIndex = 10;
              } else if (isPrev) {
                transform = 'translateX(-60%) translateZ(0) rotateY(25deg) scale(0.85)';
                opacity = 0.5;
                zIndex = 5;
              } else if (isNext) {
                transform = 'translateX(60%) translateZ(0) rotateY(-25deg) scale(0.85)';
                opacity = 0.5;
                zIndex = 5;
              }

              return (
                <div
                  key={testimonial.name}
                  className="testimonial-card absolute inset-0 flex items-center justify-center preserve-3d"
                  style={{
                    transform,
                    opacity,
                    zIndex,
                    transition: 'all 0.6s cubic-bezier(0.16, 1, 0.3, 1)'
                  }}
                >
                  <div className="w-full max-w-2xl bg-white shadow-2xl p-8 md:p-12 border border-black/10">
                    {/* Quote icon */}
                    <Quote 
                      className="w-10 h-10 mb-6 opacity-20"
                      style={{ color: testimonial.color }}
                    />

                    {/* Stars */}
                    <div className="flex gap-1 mb-6">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star 
                          key={i} 
                          className="w-5 h-5 fill-current"
                          style={{ color: testimonial.color }}
                        />
                      ))}
                    </div>

                    {/* Quote text */}
                    <blockquote className="text-xl md:text-2xl leading-relaxed mb-8 text-black/80">
                      "{testimonial.quote}"
                    </blockquote>

                    {/* Author */}
                    <div className="flex items-center gap-4">
                      {/* Avatar */}
                      <div 
                        className="w-14 h-14 rounded-full flex items-center justify-center text-white font-display font-bold text-lg"
                        style={{ backgroundColor: testimonial.color }}
                      >
                        {testimonial.initials}
                      </div>
                      
                      <div>
                        <p className="font-display text-lg font-bold">{testimonial.name}</p>
                        <p className="text-black/50 text-sm">{testimonial.role}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-6 mt-8">
            {/* Prev button */}
            <button
              onClick={prevSlide}
              className="w-12 h-12 flex items-center justify-center border border-black/20 hover:bg-black hover:text-white transition-all duration-300"
              disabled={isAnimating}
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Dots */}
            <div className="flex gap-3">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === activeIndex 
                      ? 'bg-black scale-125' 
                      : 'bg-black/20 hover:bg-black/40'
                  }`}
                  disabled={isAnimating}
                />
              ))}
            </div>

            {/* Next button */}
            <button
              onClick={nextSlide}
              className="w-12 h-12 flex items-center justify-center border border-black/20 hover:bg-black hover:text-white transition-all duration-300"
              disabled={isAnimating}
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

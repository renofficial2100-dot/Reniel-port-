import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowUpRight, ExternalLink } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const projects = [
  {
    title: 'E-Commerce Platform Redesign',
    category: 'Web Development',
    year: '2024',
    description: 'Complete overhaul of a major retail platform, resulting in 40% increase in conversions.',
    color: '#3b82f6',
    gradient: 'from-blue-600 to-blue-900'
  },
  {
    title: 'Brand Identity System',
    category: 'Branding',
    year: '2024',
    description: 'Comprehensive visual identity for a tech startup, from logo to full guidelines.',
    color: '#ec4899',
    gradient: 'from-pink-600 to-pink-900'
  },
  {
    title: 'Mobile App Interface',
    category: 'UI/UX Design',
    year: '2023',
    description: 'Intuitive mobile experience for a fitness tracking application.',
    color: '#f59e0b',
    gradient: 'from-amber-600 to-amber-900'
  },
  {
    title: 'Corporate Website',
    category: 'Web Development',
    year: '2023',
    description: 'Modern, responsive website for a Fortune 500 company.',
    color: '#10b981',
    gradient: 'from-emerald-600 to-emerald-900'
  },
  {
    title: 'Motion Campaign',
    category: 'Motion Design',
    year: '2023',
    description: 'Animated campaign that increased engagement by 200%.',
    color: '#8b5cf6',
    gradient: 'from-violet-600 to-violet-900'
  }
];

export default function Projects() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(headerRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Horizontal scroll for projects
      const container = containerRef.current;
      if (container) {
        const scrollWidth = container.scrollWidth - window.innerWidth;
        
        gsap.to(container, {
          x: -scrollWidth,
          ease: 'none',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top top',
            end: () => `+=${scrollWidth}`,
            scrub: 1,
            pin: true,
            anticipatePin: 1,
            onUpdate: (self) => {
              if (progressRef.current) {
                gsap.to(progressRef.current, {
                  scaleX: self.progress,
                  duration: 0.1
                });
              }
            }
          }
        });

        // Individual card animations
        const cards = container.querySelectorAll('.project-card');
        cards.forEach((card) => {
          gsap.fromTo(card,
            { opacity: 0.5, scale: 0.95 },
            {
              opacity: 1,
              scale: 1,
              duration: 0.5,
              scrollTrigger: {
                trigger: card,
                containerAnimation: gsap.getById('horizontal-scroll'),
                start: 'left 80%',
                end: 'left 20%',
                scrub: true
              }
            }
          );
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="projects"
      className="relative w-full min-h-screen bg-black text-white overflow-hidden"
    >
      {/* Vignette overlay */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 0%, rgba(0,0,0,0.4) 100%)'
        }}
      />

      {/* Section header */}
      <div 
        ref={headerRef}
        className="absolute top-0 left-0 w-full z-20 pt-16 md:pt-24 px-4 sm:px-8"
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <span className="text-white/50 text-sm uppercase tracking-[0.3em] mb-2 block">Portfolio</span>
            <h2 className="font-display text-5xl sm:text-6xl md:text-7xl font-bold">
              SELECTED WORKS
            </h2>
          </div>
          <p className="text-white/60 max-w-md">
            A curated collection of recent projects showcasing my expertise in design and development.
          </p>
        </div>
      </div>

      {/* Horizontal scroll container */}
      <div 
        ref={containerRef}
        className="flex items-center h-screen pt-32 gap-6 px-4 sm:px-8"
        style={{ width: 'fit-content' }}
      >
        {/* Spacer for header */}
        <div className="w-[10vw] shrink-0" />
        
        {projects.map((project, index) => (
          <div
            key={project.title}
            className="project-card relative w-[80vw] md:w-[60vw] lg:w-[50vw] h-[60vh] shrink-0 group cursor-pointer overflow-hidden"
          >
            {/* Background gradient */}
            <div 
              className={`absolute inset-0 bg-gradient-to-br ${project.gradient} transition-transform duration-700 group-hover:scale-105`}
            />
            
            {/* Pattern overlay */}
            <div 
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: `radial-gradient(circle at 2px 2px, rgba(255,255,255,0.3) 1px, transparent 0)`,
                backgroundSize: '24px 24px'
              }}
            />

            {/* Content */}
            <div className="relative h-full flex flex-col justify-end p-8 md:p-12">
              {/* Category & Year */}
              <div className="flex items-center gap-4 mb-4">
                <span 
                  className="px-3 py-1 text-xs uppercase tracking-wider border border-white/30"
                  style={{ borderColor: `${project.color}60` }}
                >
                  {project.category}
                </span>
                <span className="text-white/50 text-sm">{project.year}</span>
              </div>

              {/* Title */}
              <h3 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4 group-hover:translate-y-[-8px] transition-transform duration-400">
                {project.title}
              </h3>

              {/* Description */}
              <p className="text-white/70 max-w-md mb-6 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-400">
                {project.description}
              </p>

              {/* CTA */}
              <div className="flex items-center gap-4 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-400 delay-100">
                <button 
                  className="flex items-center gap-2 px-6 py-3 bg-white text-black font-display uppercase tracking-wider text-sm hover:bg-black hover:text-white border-2 border-white transition-all duration-300"
                >
                  View Project
                  <ArrowUpRight className="w-4 h-4" />
                </button>
                <button 
                  className="w-12 h-12 flex items-center justify-center border border-white/30 hover:bg-white hover:text-black transition-all duration-300"
                >
                  <ExternalLink className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Index number */}
            <div className="absolute top-8 right-8 font-display text-8xl font-bold text-white/10">
              0{index + 1}
            </div>

            {/* Hover border effect */}
            <div 
              className="absolute inset-0 border-2 border-transparent group-hover:border-white/20 transition-all duration-500 pointer-events-none"
            />
          </div>
        ))}

        {/* End spacer */}
        <div className="w-[20vw] shrink-0" />
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-8 left-4 sm:left-8 right-4 sm:right-8 z-20">
        <div className="h-[2px] bg-white/10 overflow-hidden">
          <div 
            ref={progressRef}
            className="h-full bg-white origin-left"
            style={{ transform: 'scaleX(0)' }}
          />
        </div>
        <div className="flex justify-between mt-4 text-sm text-white/50">
          <span>Scroll to explore</span>
          <span>{projects.length} Projects</span>
        </div>
      </div>
    </section>
  );
}
